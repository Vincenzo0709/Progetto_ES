#include "demo_system.h"
#include "dev_access.h"

void main(void)
{
	set_outputs(GPIO_OUT, 55);
}
